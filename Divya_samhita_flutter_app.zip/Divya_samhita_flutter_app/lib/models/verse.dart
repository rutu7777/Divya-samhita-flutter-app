class Verse {
  final String source;
  final String chapter;
  final List<String> keywords;
  final String verse;
  final String full_verse;
  final String explanation;

  Verse({
    required this.source,
    required this.chapter,
    required this.keywords,
    required this.verse,
    required this.full_verse,
    required this.explanation,
  });

  factory Verse.fromJson(Map<String, dynamic> json) {
    return Verse(
      source: json['source'] ?? '',
      chapter: json['chapter'] ?? '',
      keywords: List<String>.from(json['keywords'] ?? []),
      verse: json['verse'] ?? '',
      full_verse: json['full_verse'] ?? '',
      explanation: json['explanation'] ?? '',
    );
  }
}
