import 'package:flutter/material.dart';
import '../services/data_service.dart';
import '../models/verse.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController controller = TextEditingController();
  List<Verse> results = [];
  final DataService service = DataService();

  Future<void> askWisdom() async {
    final verses = await service.loadVerses('assets/data/verses.json');
    final answers = service.findMatches(verses, controller.text);

    setState(() {
      results = answers;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFFF6E5),
              Color(0xFFFDEBD0),
              Color(0xFFE8DFF5),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 20),

                /// 🌺 TITLE
                const Text(
                      "🕉️",
                  textAlign: TextAlign.center,
                     style: TextStyle(
                    fontSize: 30,
                  ),
                ),
                const Text(
                     
                  "Divya Samhita",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF4A148C),
                  ),
                ),
                const SizedBox(height: 8),

                const Text(
                  "Eternal Truths, Here and Now",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontStyle: FontStyle.italic,
                    color: Colors.black54,
                  ),
                ),

                const SizedBox(height: 28),

                /// 🔍 INPUT FIELD
                TextField(
                  controller: controller,
                  maxLines: 2,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Colors.black87,
                  ),
                  decoration: InputDecoration(
                    hintText: "Search with keywords like Life, Karma, Peace...",
                    hintStyle: const TextStyle(color: Colors.black54),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.9),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 14,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),

                const SizedBox(height: 18),

                /// 🌸 BUTTON
                ElevatedButton(
                  onPressed: askWisdom,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 30,
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    backgroundColor:
                        const Color.fromARGB(255, 220, 104, 191),
                    elevation: 6,
                  ),
                  child: const Text(
                    "Divine Guidance",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),

                const SizedBox(height: 26),

                /// 📜 RESULTS
                results.isEmpty
                    ? const SizedBox()
                    : ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: results.length,
                        itemBuilder: (context, index) {
                          final v = results[index];

                          return Container(
                            margin: const EdgeInsets.symmetric(vertical: 12),
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 231, 194, 164).withOpacity(0.95),
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(
                                color: const Color(0xFFD1A3E0),
                              ),
                              boxShadow: const [
                                BoxShadow(
                                  color: Colors.black26,
                                  blurRadius: 8,
                                  offset: Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                /// 🕉️ VERSE
                                Text(
                                  v.full_verse.isNotEmpty
                                      ? v.full_verse
                                      : v.verse,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF4A148C),
                                    height: 1.5,
                                  ),
                                ),

                                const SizedBox(height: 12),

                                /// 📖 EXPLANATION
                                Text(
                                  v.explanation,
                                  style: const TextStyle(
                                    fontSize: 15,
                                    height: 1.6,
                                    color: Colors.black87,
                                  ),
                                ),

                                const Divider(height: 28),

                                /// 📚 SOURCE
                                Text(
                                  "${v.source}${v.chapter.isNotEmpty ? ' | ${v.chapter}' : ''}",
                                  style: const TextStyle(
                                    fontStyle: FontStyle.italic,
                                    color: Colors.black54,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
