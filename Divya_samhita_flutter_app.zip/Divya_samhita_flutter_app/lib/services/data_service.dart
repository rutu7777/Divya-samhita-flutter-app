import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/verse.dart';

class DataService {
  Future<List<Verse>> loadVerses(String path) async {
    final data = await rootBundle.loadString(path);
    final List<dynamic> jsonList = json.decode(data);
    return jsonList.map((e) => Verse.fromJson(e)).toList();
  }

  List<Verse> findMatches(List<Verse> verses, String question) {
    // 1️⃣ Clean & split question
    final words = question
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .split(' ')
        .where((w) => w.length > 2) // ignore very small words
        .toList();

    List<Verse> matches = [];

    for (var v in verses) {
      for (var k in v.keywords) {
        if (words.contains(k.toLowerCase())) {
          matches.add(v);
          break;
        }
      }
    }

    // 2️⃣ If still nothing matched
    if (matches.isEmpty) {
      return [
        Verse(
          source: 'No match',
          chapter: '',
          keywords: [],
          verse: '',
          full_verse: 'No verse found',
          explanation:
              'Try using keywords like: Life, Karma, Love, Peace, Ego, Fear.',
        )
      ];
    }

    return matches;
  }
}
